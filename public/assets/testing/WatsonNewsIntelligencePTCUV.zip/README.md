
# Watson News Intelligence starter kit [![](https://img.shields.io/badge/bluemix-powered-blue.svg)](https://bluemix.net)

The Watson News Intelligence starter kit for Node.js visualizes the results of [Discovery](https://www.ibm.com/watson/services/discovery) queries. The app searches [Discovery News](https://www.ibm.com/watson/services/discovery-news) data to get insights from the news, including related concepts, entities, and sentiment trends.

## Getting started

### Running locally

These instructions are for running locally with Node.js. You can also [run locally with Docker](#running-locally-with-docker).

1. Install [Node.js](https://nodejs.org) (version 6 or later). 

1. At the command line, go to your project directory.

1. Install the dependencies:

    ```bash
    npm install
    ```

1. Start the app:

    ```bash
    npm start
    ```

1. Point your browser to [http://localhost:3000](http://localhost:3000).

---

### Testing the application

Enter a company name in the search bar to query Watson Discovery News through the app. Each panel on the page contains a visual presentation of insights derived from the API response. Press **View Query** in each panel to view the parameters of the API request and the response in JSON form.

---

### Deploy to Bluemix as CloudFoundry application

1. To deploy your project to Bluemix, you will need to install the [Bluemix CLI](https://clis.ng.bluemix.net/ui/home.html). Open a terminal and type this command:
    - MacOS
        ```
        sh <(curl -fsSL https://clis.ng.bluemix.net/install/osx)
        ```
    - Linux
        ```
        sh <(curl -fsSL https://clis.ng.bluemix.net/install/linux)
        ```
    - Windows Powershell
    
        Copy and paste the following command into a Windows PowerShell terminal console and execute it.
        ```
        iex(New-Object Net.WebClient).DownloadString('https://clis.ng.bluemix.net/install/powershell')
        ```
1. Set your API endpoint. Check the top right corner of a Bluemix page's header to determine which of the following Regions your account is set to, then run the corresponding command to set your API Endpoint.
   - US South:
      ```
      bx api https://api.ng.bluemix.net
      ```
   - Germany:
      ```
      bx api https://api.eu-de.bluemix.net
      ```
   - Sydney:
      ```
      bx api https://api.au-syd.bluemix.net
      ```
   - United Kingdom:
      ```
      bx api https://api.eu-gb.bluemix.net
      ```
You can find further documentation regarding installing Bluemix CLI, API Endpoints and Regions [here](https://console.bluemix.net/docs/cli/reference/bluemix_cli/index.html#install_bluemix_cli).

1. In your terminal go to your Project folder and run the following command to login to your Bluemix account with your Bluemix username and password.

    ```bash
    bx login
    ```

1. Push the app to Bluemix:

    ```bash
    bx app push
    ```
    The app will be deployed using the settings in your project's `manifest.yml` file.

1. Access your app at the URL specified in the command output.

    After your app is deployed, you can manage it from your [Bluemix dashboard](https://console.bluemix.net/dashboard/apps).

- - -


### See Also

#### Returning to your project in the Watson Console
- To return to your project in the IBM Watson Console, select it from your [Project List](https://console.bluemix.net/developer/watson/projects).

#### Running locally with Docker
1. Run the following command to install the [Developer Plug-in](https://console.bluemix.net/docs/cloudnative/dev_cli) for the Bluemix CLI:
    ```sh
    bx plugin install dev -r Bluemix
    ```
    - View the [documentation](https://console.bluemix.net/docs/cloudnative/dev_cli.html#developercli) for more information about the Developer Plug-in.

1. Download and install [Docker](https://www.docker.com).

1. If you installed any node dependencies into your project folder, remove them. Open a terminal and run the following command from your project folder, where your starter kit code is:
    ```
    rm -rf node_modules
    ```

1. Build the Docker container:
    ```
    bx dev build
    ```
    The build may take a few minutes to complete.
    
1. Run the Docker container:
    ```
    bx dev run
    ```
    
1. Point your browser to http://localhost:3000

### Directory structure

```none
.
├── .bluemix                        // bluemix files
├── chart                           // helm chart files for Kubernetes
├── public                          // static resources
├── server                          // server app
│   ├── config                      // express configuration
│   ├── routers                      // express routers
│   ├── services                     // express services
|   └── server.js                    // entry point
├── test                             // tests
├── manifest.yml
├── package.json
└── views                           // react components
```

## License

  This sample code is licensed under Apache 2.0.

## Open Source @ IBM

  Find more open source projects on the [IBM Github Page](http://ibm.github.io/)
